# CurrencyConverterJavaFXML
This little application can convert currencies into each other with online price query.
I created this little application with JavaFXML in Apache NetBeans and SceneBuilder. Just enter a value, choose your base-currency and the currency you wish to convert to amd the result will be displayed in a TextField. All the courses are from the web so it gets refreshed daily to be as accurate as possible. 
